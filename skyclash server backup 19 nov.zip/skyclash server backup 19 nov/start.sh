#!/bin/sh

java -Xms1024M -Xmx2048M -jar spigot-1.8.8-R0.1-SNAPSHOT-latest.jar -o true
